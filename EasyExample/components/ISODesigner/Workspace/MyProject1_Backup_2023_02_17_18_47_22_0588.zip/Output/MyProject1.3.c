// ISO-Designer ISO 11783   Version 5.6.1.5243 Jetter AG
// Do not change!

#include "MyProject1.c.h"

const unsigned long ISO_OP_MEMORY_CLASS isoOP_MyProject1_Offset_Id[] = {
	     1,  // WorkingSet_0_Offset
	    21,  // DataMask_Home_Offset
	    71,  // Container_Gesamtzaehler_Offset
	   129,  // Container_Tageszaehler_Offset
	   187,  // SoftKeyMask_Home_Offset
	   205,  // SoftKey_PlusPlus_Offset
	   218,  // SoftKey_Reset_Gesamtzaehler_Offset
	   231,  // SoftKey_Reset_Tageszaehler_Offset
	   244,  // SoftKey_MinusMinus_Offset
	   257,  // Button_PlusPlus_Offset
	   276,  // Button_Reset_Gesamtzaehler_Offset
	   295,  // Button_Reset_Tageszaehler_Offset
	   314,  // Button_MinusMinus_Offset
	   333,  // InputNumber_Gesamtziel_Offset
	   371,  // InputNumber_Tagesziel_Offset
	   409,  // OutputString_Fasszaehler_Offset
	   438,  // OutputString_Reset_Gesamtzaehler_Offset
	   468,  // OutputString_Gesamtzaehler_Offset
	   497,  // OutputString_Tageszaehler_Offset
	   525,  // OutputString_Reset_Tageszaehler_Offset
	   554,  // OutputString_SoftKey_Reset_Gesamtzaehler_Offset
	   584,  // OutputString_SoftKey_Reset_Tageszaehler_Offset
	   613,  // OutputString_Ziel_Offset
	   634,  // OutputString_ZielErreicht_Offset
	   664,  // OutputNumber_Tageszaehler_Offset
	   693,  // OutputNumber_Gesamtzaehler_Offset
	   722,  // Rectangle_Box_Offset
	   735,  // Meter_Gesamtzaehler_Offset
	   756,  // Meter_Tageszaehler_Offset
	   777,  // LinearBargraph_Gesamtzaehler_Offset
	   801,  // LinearBargraph_Tageszaehler_Offset
	   825,  // Icon_Button_MinusMinus_Offset
	  1064,  // Icon_Button_PlusPlus_Offset
	  1413,  // Icon_SoftKey_MinusMinus_Offset
	  1652,  // IconSoftKey_PlusPlus_Offset
	  2001,  // NumberVariable_Tageszaehler_Offset
	  2008,  // NumberVariable_Gesamtzaehler_Offset
	  2015,  // NumberVariable_Gesamtziel_Offset
	  2022,  // NumberVariable_Tagesziel_Offset
	  2029,  // FontAttributes_Default_Offset
	  2037,  // FontAttributes_Button_Offset
	  2045,  // LineAttributes_Border_Offset
	  2053,  // FillAttributes_DarkerBG_Offset
	  2061,  // ObjectPointer_Null2_Offset
	  2066,  // ObjectPointer_Tagesziel_Offset
	  2071,  // ObjectPointer_Null1_Offset
	  2076,  // ObjectPointer_Gesamtziel_Offset
	  2081,  // AuxFunction2_PlusPlus_Offset
	  2093,  // AuxFunction2_MinusMinus_Offset
};  // isoOP_MyProject1_Offset_Id
